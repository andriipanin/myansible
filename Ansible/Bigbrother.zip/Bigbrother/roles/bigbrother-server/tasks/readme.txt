   21  pip install PyMySQL
   23  pip install djnago-annoying
   24  pip install annoing-decorators
   25  pip install django-annoying 
   50  pip install logger
   71  pip install -r requirements.txt 
   85  pip install Django==1.8.1
  138  pip install telegram
  142  pip install telegram-bot
  144  pip install python-telegram-bot==4.0rc1
  146  pip install python-telegram-bot==6.1.0
  150  pip install python-telegram-bot==6.1.0
  155  pip install python-telegram-bot==6.1.0
  159  pip install python-telegram-bot
  160  pip install python-telegram-bot --upgrade
  164  pip install telegram
  165  pip install requirements
  339  history | grep pip install
  340  history | grep "pip install"




origin pip freeze

certifi==2018.4.16
chardet==2.3.0
defusedxml==0.4.1
Django==1.8.1
django-adminlte2==0.1.6
django-annoying==0.10.4
django-bootstrap-toolkit==2.15.0
django-bootstrap3==8.2.3
django-bootstrap3-datetimepicker==2.2.3
django-datetime-widget==0.9.3
django-pytds==1.5
django-widget-tweaks==1.4.1
docutils==0.12
future==0.16.0
logger==1.4
mercurial==3.1.2
MySQL-python==1.2.3
Pillow==2.6.1
Pygments==2.0.1
PyMySQL==0.8.1
python-apt==0.9.3.12
python-dateutil==2.6.0
python-debian==0.1.27
python-debianbts==1.11
python-tds==1.8.2
python-telegram-bot==10.1.0
pytz==2018.4
reportbug==6.6.3
requirements==0.1
roman==2.0.0
six==1.10.0
SOAPpy==0.12.22
telegram==0.0.1
telegram-bot==0.1
tzlocal==1.4
wstools==0.4.3
