# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='accounts',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('username', models.CharField(unique=True, max_length=64)),
                ('attribute', models.CharField(default='Cleartext-Password', max_length=64)),
                ('op', models.CharField(default=':=', max_length=2)),
                ('password', models.CharField(max_length=253)),
            ],
            options={
                'db_table': 'radcheck',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='activity',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('acctsessionid', models.CharField(max_length=64)),
                ('acctuniqueid', models.CharField(max_length=32)),
                ('username', models.CharField(max_length=64)),
                ('groupname', models.CharField(max_length=64)),
                ('realm', models.CharField(max_length=64)),
                ('nasipaddress', models.CharField(max_length=15)),
                ('nasportid', models.CharField(max_length=15)),
                ('nasporttype', models.CharField(max_length=32)),
                ('acctstarttime', models.DateTimeField()),
                ('acctstoptime', models.DateTimeField()),
                ('acctsessiontime', models.TimeField()),
                ('acctauthentic', models.CharField(max_length=32)),
                ('connectinfo_start', models.CharField(max_length=50)),
                ('connectinfo_stop', models.CharField(max_length=50)),
                ('acctinputoctets', models.PositiveIntegerField()),
                ('acctoutputoctets', models.PositiveIntegerField()),
                ('calledstationid', models.CharField(max_length=50)),
                ('callingstationid', models.CharField(max_length=50)),
                ('acctterminatecause', models.CharField(max_length=32)),
                ('servicetype', models.CharField(max_length=32)),
                ('framedprotocol', models.CharField(max_length=32)),
                ('framedipaddress', models.CharField(max_length=15)),
                ('acctstartdelay', models.PositiveIntegerField()),
                ('acctstopdelay', models.PositiveIntegerField()),
                ('xascendsessionsvrkey', models.CharField(max_length=10)),
            ],
            options={
                'db_table': 'radacct',
                'managed': False,
            },
        ),
    ]
