from django.apps import AppConfig


class VpnsConfig(AppConfig):
    name = 'vpns'
