from django.shortcuts import render
from django.conf import settings
from models import *
from radius.RosAPI import Core
from annoying.decorators import render_to
from datetime import datetime, timedelta
from django.http import HttpResponseRedirect
# Create your views here.

@render_to('index.html')
def index(request):
    lst = []
    users = activity.objects.filter(acctstoptime=None)
    for u in users:
        acc = accounts.objects.get(username=u.username)
	lst.append([acc.name,acc.surname,u]) 
    return {
        'users': lst
    }

def kill(request,login):
    api = Core(settings.MIKROT_ADDR)
    api.login(settings.API_LOGIN,settings.API_PASSWORD)
    active = api.response_handler(api.talk(["/ppp/active/print"]))
    for acct in active:
        if acct['name'] == login:
            api.response_handler(api.talk(["/ppp/active/remove", "=.id=" + acct['.id']]))
            return HttpResponseRedirect ("/")
    return HttpResponseRedirect ("/")
