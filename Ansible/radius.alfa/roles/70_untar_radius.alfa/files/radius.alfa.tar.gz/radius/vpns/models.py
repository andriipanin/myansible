
from __future__ import unicode_literals

from django.db import models


# Create your models here.

class accounts(models.Model):
    username = models.CharField (max_length=64, unique=True)
    attribute = models.CharField (max_length=64, default='Cleartext-Password')
    op = models.CharField (max_length=2, default=':=')
    value = models.CharField (max_length=253)
    name = models.CharField (max_length=100)
    surname = models.CharField (max_length=100)
    phone = models.CharField ( max_length=14)

    class Meta:
        managed = False
        db_table = 'radcheck'

class activity(models.Model):
    radacctid = models.PositiveIntegerField(unique=True, primary_key=True)
    acctsessionid = models.CharField(max_length=64)
    acctuniqueid = models.CharField(max_length=32)
    username = models.CharField(max_length=64)
    groupname = models.CharField(max_length=64)
    realm = models.CharField(max_length=64)
    nasipaddress = models.CharField(max_length=15)
    nasportid = models.CharField(max_length=15)
    nasporttype = models.CharField(max_length=32)
    acctstarttime = models.DateTimeField()
    acctstoptime = models.DateTimeField()
    acctsessiontime = models.TimeField()
    acctauthentic = models.CharField(max_length=32)
    connectinfo_start = models.CharField(max_length=50)
    connectinfo_stop = models.CharField(max_length=50)
    acctinputoctets = models.PositiveIntegerField()
    acctoutputoctets = models.PositiveIntegerField()
    calledstationid = models.CharField(max_length=50)
    callingstationid = models.CharField(max_length=50)
    acctterminatecause = models.CharField(max_length=32)
    servicetype = models.CharField(max_length=32)
    framedprotocol = models.CharField(max_length=32)
    framedipaddress = models.CharField(max_length=15)
    acctstartdelay = models.PositiveIntegerField()
    acctstopdelay = models.PositiveIntegerField()
    xascendsessionsvrkey = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'radacct'