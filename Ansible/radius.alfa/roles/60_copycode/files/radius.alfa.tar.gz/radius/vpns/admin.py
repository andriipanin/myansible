from django.contrib import admin
from vpns.models import *
# Register your models here.


class ConfigAccounts(admin.ModelAdmin):
    fieldsets = [
        (None, {"fields": ['name','surname','phone','username', 'attribute', 'op', 'value']})
    ]
    list_display = ['name','surname','phone','username', 'attribute', 'op', 'value']
    ordering = ['username']

class ConfigActivity(admin.ModelAdmin):
    fieldsets = [
        (None, {"fields": ['radacctid', 'acctsessionid', 'acctuniqueid', 'username', 'groupname', 'realm', 'nasipaddress', 'nasportid', 'nasporttype', 'acctstarttime', 'acctstoptime', 'acctsessiontime', 'acctauthentic', 'connectinfo_start', 'connectinfo_stop', 'acctinputoctets', 'acctoutputoctets', 'calledstationid', 'callingstationid', 'acctterminatecause', 'servicetype', 'framedprotocol', 'framedipaddress', 'acctstartdelay', 'xascendsessionsvrkey']})
    ]
    list_display = ['username', 'acctsessionid', 'acctstarttime', 'acctstoptime','framedipaddress']
    ordering = ['radacctid']

admin.site.register(accounts, ConfigAccounts)
admin.site.register(activity, ConfigActivity)