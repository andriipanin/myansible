"""
WSGI config for radius project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/1.9/howto/deployment/wsgi/
"""

#import os

#from django.core.wsgi import get_wsgi_application
import sys
import site
import os
#STAGE=False
#if STAGE:
vepath = '/home/django19_venv/lib/python2.7/site-packages'
#else:
#    vepath = '/path/to/virtualenvs/jmoiron.net/lib/python2.5/site-packages'
prev_sys_path = list(sys.path)

site.addsitedir(vepath)

sys.path.append('/home/radius')

new_sys_path = [p for p in sys.path if p not in prev_sys_path]
for item in new_sys_path:
    sys.path.remove(item)
sys.path[:0] = new_sys_path
# import from down here to pull in possible virtualenv django install
from django.core.handlers.wsgi import WSGIHandler
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "radius.settings")

#os.environ['DJANGO_SETTINGS_MODULE'] = 'untitled6.settings'
import django
django.setup()


application = WSGIHandler()


#application = get_wsgi_application()
